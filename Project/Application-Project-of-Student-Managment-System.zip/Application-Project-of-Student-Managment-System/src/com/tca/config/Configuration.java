package com.tca.config;

public interface Configuration
{
    public static final String FILE_NAME="resources/Student.csv";
}
